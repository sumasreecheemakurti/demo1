package com.bean;

public class Student {
private String name;
private int EMPID;
private String gender;
private String DOB;
public Student(String name, int eMPID, String gender, String dOB) {
	super();
	this.name = name;
	EMPID = eMPID;
	this.gender = gender;
	DOB = dOB;
}

public Student() {
	super();
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getEMPID() {
	return EMPID;
}
public void setEMPID(int eMPID) {
	EMPID = eMPID;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getDOB() {
	return DOB;
}
public void setDOB(String dOB) {
	DOB = dOB;
}

}
