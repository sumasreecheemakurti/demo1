package com.dao.copy;

import java.sql.*;
import java.util.*;

import com.bean.*;

import com.util.*;

public class StudentDao {
	Connection con;
	PreparedStatement ps;
	
	public boolean addStudent(Student s) 
	{
	
	boolean flag=false;
		try{
		con=DataBaseUtil.getConnection();
		ps=con.prepareStatement("insert into Student  values(?,?,?,?)");
		ps.setString(1,s.getName());
		ps.setInt(2, s.getEMPID());
		ps.setString(3,s.getGender());
		ps.setString(4,s.getDOB());
		int i=ps.executeUpdate();
		if(i>0)
			flag=true;
	}catch(SQLException e)
	{
		e.printStackTrace();
	}
return flag;
}
	public ArrayList<Student> viewStudent(Student s) 
	{
		 ArrayList<Student> i=new  ArrayList<Student>();
	boolean flag=false;
		try{
		con=DataBaseUtil.getConnection();
		ps=con.prepareStatement("select * from Student");
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			Student r=new Student();
			r.setName(rs.getString(1));
			r.setEMPID(rs.getInt(2));
			r.setGender(rs.getString(3));
			r.setDOB(rs.getString(4));
			i.add(r);
			}
}catch(SQLException e)
{
	e.printStackTrace();
}
		return i;
}
}