package com.service;

import java.util.ArrayList;

import com.bean.Student;
import com.dao.copy.StudentDao;

public class StudentService {
	StudentDao sd=new StudentDao();
	public boolean addStudent(Student s) 
	{
		return sd.addStudent(s);
	}
	public ArrayList<Student> viewStudent(Student s) 
	{
		ArrayList<Student> a =new  ArrayList<Student>();
		a= sd.viewStudent(s);
		return a;
	}
}
