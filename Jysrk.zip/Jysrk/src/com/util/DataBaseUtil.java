package com.util;
import java.sql.*;
public class DataBaseUtil {
	public static Connection getConnection(){
		
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@172.25.192.82:1521:db","HJA06ORAUSER1D","tcshyd");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return con;
	}
	public static void closeConnection(Connection con){
		if(con!=null){
			try{
				con.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		
	}
	public static void closeStatement(PreparedStatement ps){
		if(ps!=null){
			try{
				ps.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		
	}

}
